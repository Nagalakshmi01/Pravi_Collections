PRAVI COLLECTIONS — WEBSITE V2

Files:
- index.html
- assets/logo.jpg

GitHub Pages:
1. Open your Pravi_Collections repository.
2. Upload/replace index.html.
3. Upload the assets folder and logo.jpg.
4. Commit changes.
5. GitHub Pages will publish the updated site.

Instagram:
https://www.instagram.com/pravi_collections_tn/

Important:
- No phone number is included because a business number was not confirmed.
- Product cards are placeholders until actual product photos are added.

PRAVI COLLECTIONS WEBSITE

Files:
- index.html — complete responsive website.

How to use:
1. Open index.html in a browser to preview it.
2. When you are ready to publish, upload index.html to a website host.
3. The Instagram buttons already point to @pravi_collections_tn.
4. When you have a business WhatsApp number, we can add a WhatsApp button.
5. When your products arrive, we can replace the "Coming Soon" section with product photos, prices, sizes and an order system.
